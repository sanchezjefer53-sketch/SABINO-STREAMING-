const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProfileSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true, maxlength: 20 },
  avatar: String,
  isKids: { type: Boolean, default: false },
  language: { type: String, enum: ['es','en','fr','de','it','pt'], default: 'es' },
  watchlist: [{
    content: { type: Schema.Types.ObjectId, refPath: 'watchlist.contentType' },
    contentType: String,
    addedAt: { type: Date, default: Date.now }
  }],
  preferences: {
    genres: [String],
    autoplay: { type: Boolean, default: true },
    subtitles: {
      enabled: { type: Boolean, default: false },
      language: { type: String, default: 'es' }
    }
  },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Profile', ProfileSchema);
