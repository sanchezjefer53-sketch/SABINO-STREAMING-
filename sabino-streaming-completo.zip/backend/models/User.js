const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const WatchHistorySchema = new Schema({
  content: { type: Schema.Types.ObjectId, refPath: 'watchHistory.contentType' },
  contentType: { type: String, enum: ['Movie','Series'] },
  watchedAt: { type: Date, default: Date.now },
  progress: { type: Number, default: 0 }
});

const SubscriptionSchema = new Schema({
  plan: { type: String, enum: ['free','basic','standard','premium'], default: 'free' },
  status: { type: String, enum: ['active','canceled','past_due','inactive'], default: 'inactive' },
  stripeCustomerId: String,
  stripeSubscriptionId: String,
  currentPeriodEnd: Date
});

const UserSchema = new Schema({
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  isAdmin: { type: Boolean, default: false },
  subscription: { type: SubscriptionSchema, default: () => ({}) },
  profiles: [{ type: Schema.Types.ObjectId, ref: 'Profile' }],
  watchHistory: [WatchHistorySchema],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', UserSchema);
