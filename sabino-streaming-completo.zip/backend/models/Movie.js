const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SubtitleSchema = new Schema({
  language: String,
  languageCode: String,
  url: String
});

const MovieSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  duration: { type: Number, required: true },
  releaseYear: { type: Number, required: true },
  genre: [String],
  rating: { type: Number, default: 0 },
  ageRating: { type: String, enum: ['ATP','13+','16+','18+'], default: 'ATP' },
  thumbnail: { type: String, required: true },
  bannerImage: String,
  videoUrl: { type: String, required: true },
  trailerUrl: String,
  cast: [String],
  director: String,
  subtitles: [SubtitleSchema],
  views: { type: Number, default: 0 },
  likes: { type: Number, default: 0 },
  featured: { type: Boolean, default: false },
  trending: { type: Boolean, default: false },
  isKidsContent: { type: Boolean, default: false },
  requiredPlan: { type: String, enum: ['free','basic','standard','premium'], default: 'free' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Movie', MovieSchema);
