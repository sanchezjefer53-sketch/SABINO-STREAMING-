const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const EpisodeSchema = new Schema({
  episodeNumber: Number,
  title: String,
  description: String,
  duration: Number,
  thumbnail: String,
  videoUrl: String,
  subtitles: [Object],
  views: { type: Number, default: 0 }
});

const SeasonSchema = new Schema({
  seasonNumber: Number,
  title: String,
  episodes: [EpisodeSchema]
});

const SeriesSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  releaseYear: Number,
  genre: [String],
  rating: Number,
  ageRating: String,
  thumbnail: String,
  bannerImage: String,
  trailerUrl: String,
  cast: [String],
  creator: String,
  seasons: [SeasonSchema],
  totalSeasons: Number,
  views: { type: Number, default: 0 },
  featured: { type: Boolean, default: false },
  trending: { type: Boolean, default: false },
  isKidsContent: { type: Boolean, default: false },
  requiredPlan: { type: String, enum: ['free','basic','standard','premium'], default: 'free' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Series', SeriesSchema);
