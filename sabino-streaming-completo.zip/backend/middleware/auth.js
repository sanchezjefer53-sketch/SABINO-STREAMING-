const jwt = require('jsonwebtoken');
const User = require('../models/User');

module.exports = async function(req,res,next){
  const token = req.header('Authorization')?.replace('Bearer ','') || req.query.token;
  if(!token) return res.status(401).json({message:'Token no proporcionado'});
  try{
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');
    if(!user) return res.status(401).json({message:'Usuario no encontrado'});
    req.user = user;
    next();
  }catch(err){
    return res.status(401).json({message:'Token inválido', error: err.message});
  }
};
