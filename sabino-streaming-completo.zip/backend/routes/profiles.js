const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Profile = require('../models/Profile');
const User = require('../models/User');

// List profiles
router.get('/', auth, async (req,res)=>{
  const profiles = await Profile.find({ user: req.user._id });
  res.json(profiles);
});

// Create profile
router.post('/', auth, async (req,res)=>{
  try{
    const { name, avatar, isKids, language } = req.body;
    const count = await Profile.countDocuments({ user: req.user._id });
    if(count >= 5) return res.status(400).json({message:'Máximo 5 perfiles'});
    const profile = new Profile({ user: req.user._id, name, avatar, isKids, language });
    await profile.save();
    req.user.profiles.push(profile._id);
    await req.user.save();
    res.json(profile);
  }catch(err){ res.status(500).json({message:'Error creando perfil', error: err.message}); }
});

// Get specific
router.get('/:id', auth, async (req,res)=>{
  const profile = await Profile.findById(req.params.id);
  if(!profile) return res.status(404).json({message:'No encontrado'});
  if(profile.user.toString() !== req.user._id.toString()) return res.status(403).json({message:'No autorizado'});
  res.json(profile);
});

// Watchlist endpoints (add/remove/get)
router.post('/:profileId/watchlist', auth, async (req,res)=>{
  const { contentId, contentType } = req.body;
  const profile = await Profile.findById(req.params.profileId);
  if(!profile) return res.status(404).json({message:'Perfil no encontrado'});
  profile.watchlist.push({ content: contentId, contentType, addedAt: new Date() });
  await profile.save();
  res.json(profile.watchlist);
});

router.get('/:profileId/watchlist', auth, async (req,res)=>{
  const profile = await Profile.findById(req.params.profileId);
  res.json(profile.watchlist || []);
});

router.delete('/:profileId/watchlist/:contentId', auth, async (req,res)=>{
  const profile = await Profile.findById(req.params.profileId);
  profile.watchlist = profile.watchlist.filter(i => i.content.toString() !== req.params.contentId);
  await profile.save();
  res.json(profile.watchlist);
});

module.exports = router;
