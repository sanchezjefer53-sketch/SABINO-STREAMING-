const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const SALT_ROUNDS = 10;

// Register
router.post('/register', async (req,res)=>{
  try{
    const { name, email, password } = req.body;
    if(!email || !password || !name) return res.status(400).json({message:'Faltan campos'});
    if(password.length < 6) return res.status(400).json({message:'La contraseña debe tener al menos 6 caracteres'});
    const existing = await User.findOne({ email: email.toLowerCase() });
    if(existing) return res.status(400).json({message:'Email ya registrado'});
    const hash = await bcrypt.hash(password, SALT_ROUNDS);
    const user = new User({ name, email, password: hash, subscription: { plan: 'free', status: 'active' }});
    await user.save();
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user: { email: user.email, name: user.name, id: user._id }});
  }catch(err){
    console.error(err);
    res.status(500).json({message:'Error en registro', error: err.message});
  }
});

// Login
router.post('/login', async (req,res)=>{
  try{
    const { email, password } = req.body;
    if(!email || !password) return res.status(400).json({message:'Faltan campos'});
    const user = await User.findOne({ email: email.toLowerCase() });
    if(!user) return res.status(400).json({message:'Credenciales inválidas'});
    const match = await bcrypt.compare(password, user.password);
    if(!match) return res.status(400).json({message:'Credenciales inválidas'});
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user: { email: user.email, name: user.name, id: user._id, isAdmin: user.isAdmin }});
  }catch(err){
    console.error(err);
    res.status(500).json({message:'Error en login', error: err.message});
  }
});

// Verify token
const authMw = require('../middleware/auth');
router.get('/verify', authMw, (req,res)=> {
  res.json({ ok:true, user: req.user });
});

module.exports = router;
