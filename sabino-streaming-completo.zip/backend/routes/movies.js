const express = require('express');
const router = express.Router();
const Movie = require('../models/Movie');

// List with queries
router.get('/', async (req,res)=>{
  try{
    const { search, genre, featured, trending, limit=20 } = req.query;
    const q = {};
    if(search) q.title = new RegExp(search, 'i');
    if(genre) q.genre = genre;
    if(featured) q.featured = true;
    if(trending) q.trending = true;
    const movies = await Movie.find(q).limit(parseInt(limit));
    res.json(movies);
  }catch(err){ res.status(500).json({message:'Error listando películas', error: err.message}); }
});

router.get('/featured', async (req,res)=> {
  const movies = await Movie.find({ featured: true }).limit(10);
  res.json(movies);
});

router.get('/trending', async (req,res)=> {
  const movies = await Movie.find({ trending: true }).limit(10);
});

router.get('/genres', async (req,res)=>{
  const genres = await Movie.distinct('genre');
  res.json(genres);
});

router.get('/:id', async (req,res)=>{
  try{
    const movie = await Movie.findById(req.params.id);
    if(!movie) return res.status(404).json({message:'No encontrado'});
    res.json(movie);
  }catch(err){ res.status(500).json({message:'Error al obtener detalle', error: err.message}); }
});

router.post('/:id/like', async (req,res)=>{
  try{
    const movie = await Movie.findById(req.params.id);
    if(!movie) return res.status(404).json({message:'No encontrado'});
    movie.likes = (movie.likes||0) + 1;
    await movie.save();
    res.json({ ok:true, likes: movie.likes });
  }catch(err){ res.status(500).json({message:'Error en like', error: err.message}); }
});

// Simple search endpoint
router.get('/search/:query', async (req,res)=>{
  const q = req.params.query;
  const movies = await Movie.find({ $or: [ { title: new RegExp(q,'i') }, { description: new RegExp(q,'i') } ] }).limit(50);
  res.json(movies);
});

module.exports = router;
