const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const Movie = require('../models/Movie');
const User = require('../models/User');

// Stats
router.get('/stats', auth, admin, async (req,res)=>{
  const totalMovies = await Movie.countDocuments();
  const totalUsers = await User.countDocuments();
  const top = await Movie.find().sort({ views: -1 }).limit(10);
  res.json({ totalMovies, totalUsers, top });
});

// CRUD Movie (create/edit/delete)
router.post('/movies', auth, admin, async (req,res)=>{
  try{
    const m = new Movie(req.body);
    await m.save();
    res.json(m);
  }catch(err){ res.status(500).json({message:'Error crear película', error: err.message}); }
});

router.put('/movies/:id', auth, admin, async (req,res)=>{
  const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(movie);
});

router.delete('/movies/:id', auth, admin, async (req,res)=>{
  await Movie.findByIdAndDelete(req.params.id);
  res.json({ ok:true });
});

router.get('/users', auth, admin, async (req,res)=>{
  const users = await User.find().select('-password');
  res.json(users);
});

router.put('/users/:id/admin', auth, admin, async (req,res)=>{
  const user = await User.findById(req.params.id);
  user.isAdmin = !user.isAdmin;
  await user.save();
  res.json(user);
});

module.exports = router;
