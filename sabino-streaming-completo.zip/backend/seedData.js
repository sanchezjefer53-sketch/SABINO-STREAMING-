/**
 * seedData.js - pobla la DB con datos de ejemplo
 * Usa videos públicos (Big Buck Bunny) y placeholders
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/database');
const User = require('./models/User');
const Movie = require('./models/Movie');
const Series = require('./models/Series');
const bcrypt = require('bcrypt');

async function seed(){
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/sabino-streaming');
  console.log('Mongo connected for seeding');
  await User.deleteMany({});
  await Movie.deleteMany({});
  await Series.deleteMany({});

  const hashAdmin = await bcrypt.hash('admin123', 10);
  const hashUser = await bcrypt.hash('test123', 10);

  const admin = await User.create({ name: 'Admin Sabino', email: 'admin@sabino.com', password: hashAdmin, isAdmin: true, subscription: { plan: 'premium', status: 'active' }});
  const user = await User.create({ name: 'Usuario Test', email: 'usuario@test.com', password: hashUser, subscription: { plan: 'free', status: 'active' }});

  const sampleVideos = [
    { title: 'Big Buck Bunny', file: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
    { title: 'Sintel', file: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4' },
    { title: 'Elephants Dream', file: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' }
  ];

  const movies = [
    { title: 'Big Buck Bunny', description: 'Animación de ejemplo', duration: 10, releaseYear: 2008, genre: ['Animación','Comedia'], rating: 8.5, ageRating: 'ATP', thumbnail: 'https://picsum.photos/300/450?random=1', bannerImage: 'https://picsum.photos/1200/400?random=11', videoUrl: sampleVideos[0].file, trailerUrl: sampleVideos[0].file, cast: ['Actor A'], director: 'Director X', requiredPlan: 'free', featured: true },
    { title: 'Sintel', description: 'Corto abierto', duration: 14, releaseYear: 2010, genre: ['Acción','Aventura'], rating: 7.9, ageRating: '13+', thumbnail: 'https://picsum.photos/300/450?random=2', bannerImage: 'https://picsum.photos/1200/400?random=12', videoUrl: sampleVideos[1].file, requiredPlan: 'basic', trending: true },
    { title: 'Elephants Dream', description: 'Corto experimental', duration: 12, releaseYear: 2006, genre: ['Drama'], rating: 7.2, ageRating: '16+', thumbnail: 'https://picsum.photos/300/450?random=3', bannerImage: 'https://picsum.photos/1200/400?random=13', videoUrl: sampleVideos[2].file, requiredPlan: 'standard' }
  ];

  for(const m of movies){
    await Movie.create(m);
  }

  console.log('Seed complete. Usuarios: admin@sabino.com / admin123  - usuario@test.com / test123');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
