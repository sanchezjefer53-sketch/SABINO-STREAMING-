# Sabino Streaming

Creado por: Gian Carlos Sabino Chabarrea

Proyecto: Sabino Streaming — plataforma de streaming tipo Netflix (scaffold funcional).

## Estructura principal
- backend/ : API en Node.js + Express + MongoDB (Mongoose)
- frontend/: Frontend en React 18 + Vite

## Requisitos previos
- Node.js v16+
- npm
- MongoDB corriendo localmente (o URL en .env)

## Cómo ejecutar

### Backend
```bash
cd backend
cp .env.example .env
# editar .env si es necesario
npm install
npm run seed     # poblar DB con datos de ejemplo
npm run dev      # arranca servidor en PORT (por defecto 5000)
```

### Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
# Vite por defecto en http://localhost:5173
```

## Credenciales de prueba (seed)
- admin: admin@sabino.com / admin123
- user: usuario@test.com / test123

## Notas
- Videos de ejemplo utilizan enlaces públicos (ej. Big Buck Bunny).
- Cloudinary/Stripe están configurados como opcionales; introducir claves en .env si desea uso real.
- Este repositorio es un **scaffold** funcional con las rutas y lógica base solicitada. Para producción, debe endurecerse (HTTPS, validación avanzada, manejo de CORS, etc.).

© 2024 Gian Carlos Sabino Chabarrea - Sabino Streaming
