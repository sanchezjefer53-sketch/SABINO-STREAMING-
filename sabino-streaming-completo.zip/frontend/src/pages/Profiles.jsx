import React, {useEffect, useState} from 'react';
import axios from 'axios';

export default function Profiles(){
  const [profiles, setProfiles] = useState([]);
  useEffect(()=> {
    const token = localStorage.getItem('token');
    if(!token) return;
    axios.get(import.meta.env.VITE_API_URL + '/profiles', { headers: { Authorization: 'Bearer ' + token } })
      .then(r=> setProfiles(r.data)).catch(()=>{});
  },[]);
  return (
    <div style={{paddingTop:80}}>
      <h2 style={{padding:20}}>Selector de perfiles</h2>
      <div style={{display:'flex',gap:12,padding:20}}>
        {profiles.length === 0 ? <p>No hay perfiles</p> : profiles.map(p => <div key={p._id} style={{padding:12,background:'#222',borderRadius:8}}>{p.name}</div>)}
      </div>
    </div>
  );
}
