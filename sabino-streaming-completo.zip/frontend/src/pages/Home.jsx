import React, {useEffect, useState} from 'react';
import axios from 'axios';
import MovieCard from '../components/MovieCard';

export default function Home(){
  const [movies, setMovies] = useState([]);
  useEffect(()=> {
    axios.get(import.meta.env.VITE_API_URL + '/movies').then(r=> setMovies(r.data)).catch(()=>{});
  },[]);
  return (
    <main style={{paddingTop:80}}>
      <h1 style={{padding:'0 20px'}}>Destacados</h1>
      <div style={{display:'flex',gap:12,overflowX:'auto',padding:'12px 20px'}}>
        {movies.map(m => <MovieCard key={m._id} movie={m} />)}
      </div>
      <footer style={{padding:20,color:'#808080'}}>Creado por Gian Carlos Sabino Chabarrea</footer>
    </main>
  );
}
