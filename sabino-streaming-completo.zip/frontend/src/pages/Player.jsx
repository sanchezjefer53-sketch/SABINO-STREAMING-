import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

export default function Player(){
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  useEffect(()=> {
    axios.get(import.meta.env.VITE_API_URL + '/movies/' + id).then(r=> setMovie(r.data)).catch(()=>{});
  },[id]);
  if(!movie) return <div style={{paddingTop:80}}>Cargando...</div>;
  return (
    <div style={{paddingTop:80,padding:20}}>
      <h2>{movie.title}</h2>
      <video controls style={{maxWidth:'100%'}} src={movie.videoUrl} />
      <p>{movie.description}</p>
    </div>
  );
}
