import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';
export default function Navbar(){
  return (
    <nav className='nav'>
      <div className='nav-left'>
        <Link to='/' className='logo'>Sabino<span>Streaming</span></Link>
      </div>
      <div className='nav-right'>
        <Link to='/profiles'>Perfiles</Link>
        <Link to='/login'>Iniciar sesión</Link>
      </div>
    </nav>
  );
}
