import React from 'react';
import './MovieCard.css';
import { Link } from 'react-router-dom';
export default function MovieCard({movie}){
  return (
    <div className='movie-card'>
      <img src={movie.thumbnail} alt={movie.title} />
      <div className='info'>
        <h4>{movie.title}</h4>
        <p>{movie.releaseYear} • {movie.duration}m</p>
        <div className='actions'>
          <Link to={'/player/' + movie._id}>Reproducir</Link>
        </div>
      </div>
    </div>
  );
}
