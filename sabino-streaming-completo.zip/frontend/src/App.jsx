import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Profiles from './pages/Profiles';
import Player from './pages/Player';
import Navbar from './components/Navbar';
import './App.css';

export default function App(){
  return (
    <div className='app'>
      <Navbar />
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/register' element={<Register/>} />
        <Route path='/profiles' element={<Profiles/>} />
        <Route path='/player/:id' element={<Player/>} />
      </Routes>
    </div>
  );
}
